package ntnu.adriawh.oving4
import android.media.Image

data class Movie(
    var title : String,
    var description : String,
    var image: Image
)
