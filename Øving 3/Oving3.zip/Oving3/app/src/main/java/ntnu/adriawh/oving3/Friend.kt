package ntnu.adriawh.oving3

import java.util.*

data class Friend(
    var navn: String,
    var fødselsdato: String
)
