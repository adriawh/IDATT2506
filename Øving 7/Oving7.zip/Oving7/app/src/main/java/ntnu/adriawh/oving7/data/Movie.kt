package ntnu.adriawh.oving7.data

data class Movie(
  var title: String,
  var director: String,
  var actors: List<String>
)
